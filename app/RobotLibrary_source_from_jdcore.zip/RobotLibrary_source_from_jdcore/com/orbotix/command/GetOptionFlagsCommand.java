package com.orbotix.command;

import com.orbotix.common.internal.DeviceCommand;
import com.orbotix.common.internal.DeviceId;
import com.orbotix.common.internal.RobotCommandId;


public class GetOptionFlagsCommand
  extends DeviceCommand
{
  public GetOptionFlagsCommand() {}
  
  public byte getDeviceId()
  {
    return DeviceId.ROBOT.getValue();
  }
  
  public byte getCommandId()
  {
    return RobotCommandId.GET_OPTION_FLAGS.getValue();
  }
}
