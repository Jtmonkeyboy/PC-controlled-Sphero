package com.orbotix.command;

public class AutoReconnectCommand
{
  public AutoReconnectCommand() {}
}
