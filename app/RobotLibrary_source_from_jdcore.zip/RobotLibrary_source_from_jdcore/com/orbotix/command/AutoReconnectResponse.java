package com.orbotix.command;

public class AutoReconnectResponse
{
  public AutoReconnectResponse() {}
}
