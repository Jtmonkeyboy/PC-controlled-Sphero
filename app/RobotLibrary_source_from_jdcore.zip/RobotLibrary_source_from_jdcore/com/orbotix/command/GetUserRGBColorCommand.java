package com.orbotix.command;

import com.orbotix.common.internal.DeviceCommand;
import com.orbotix.common.internal.DeviceId;
import com.orbotix.common.internal.RobotCommandId;






public class GetUserRGBColorCommand
  extends DeviceCommand
{
  public GetUserRGBColorCommand() {}
  
  public byte getDeviceId()
  {
    return DeviceId.ROBOT.getValue();
  }
  
  public byte getCommandId()
  {
    return RobotCommandId.RGB_LED_OUTPUT.getValue();
  }
}
