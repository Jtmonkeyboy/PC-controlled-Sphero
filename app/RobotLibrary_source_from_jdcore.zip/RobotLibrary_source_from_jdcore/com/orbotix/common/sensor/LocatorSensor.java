package com.orbotix.common.sensor;



public class LocatorSensor
{
  public float x;
  

  public float y;
  


  public LocatorSensor() {}
  


  public String toString()
  {
    return "Locator{x=" + x + ", y=" + y + '}';
  }
}
