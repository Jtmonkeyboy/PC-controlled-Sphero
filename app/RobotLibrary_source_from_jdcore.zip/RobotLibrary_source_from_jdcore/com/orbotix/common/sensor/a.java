package com.orbotix.common.sensor;




abstract class a
{
  private long a;
  


  public a()
  {
    a = System.currentTimeMillis();
  }
  
  public long getTimeStamp() {
    return a;
  }
}
