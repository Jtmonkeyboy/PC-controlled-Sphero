package com.orbotix.common;

public enum DiscoveryExceptionCode
{
  private DiscoveryExceptionCode() {}
}
