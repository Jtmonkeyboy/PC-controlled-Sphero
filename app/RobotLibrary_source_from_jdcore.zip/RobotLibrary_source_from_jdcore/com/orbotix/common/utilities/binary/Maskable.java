package com.orbotix.common.utilities.binary;

public abstract interface Maskable
{
  public abstract long longValue();
}
