package com.orbotix.common.internal;

public enum RadioConnectionState
{
  private RadioConnectionState() {}
}
