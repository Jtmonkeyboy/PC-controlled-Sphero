package com.orbotix.le;

public class LeScanRecord
{
  public LeScanRecord() {}
}
