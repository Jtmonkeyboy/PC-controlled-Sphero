package com.orbotix.le;

public abstract interface LeLinkInterface
{
  public abstract void sendRaw(byte[] paramArrayOfByte);
}
