package com.orbotix.le.connectstrategy;

import com.orbotix.common.Robot;
import java.util.List;

public class IfOneConnectStrategy implements ConnectStrategy
{
  private a a = new a();
  
  public IfOneConnectStrategy() {}
  
  public Robot getRobotToConnectFromAvailableNodes(List<Robot> availableRobots, Robot latestRobot) { return a.getRobotToConnectFromAvailableNodes(availableRobots, latestRobot); }
}
