package com.orbotix.le;

import com.orbotix.common.Robot;

public abstract interface RobotLeRadioAckDelegate
{
  public abstract void handleACK(Robot paramRobot);
}
