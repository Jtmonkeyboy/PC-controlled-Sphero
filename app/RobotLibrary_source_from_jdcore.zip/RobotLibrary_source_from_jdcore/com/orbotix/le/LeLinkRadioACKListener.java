package com.orbotix.le;

public abstract interface LeLinkRadioACKListener
{
  public abstract void didACK();
}
