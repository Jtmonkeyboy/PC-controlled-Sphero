package com.orbotix.classic;

import com.orbotix.common.DiscoveryAgentProxy;

public abstract interface DiscoveryAgentClassicProxy
  extends DiscoveryAgentProxy
{}
